document.addEventListener('DOMContentLoaded', function() {
    var decryptButton = document.getElementById('decryptButton');
    decryptButton.addEventListener('click', function() {
      var ciphertext = document.getElementById('ciphertext').value.trim();
      var key = document.getElementById('key').value.trim();
      var decrypted = CryptoJS.AES.decrypt(ciphertext, key).toString(CryptoJS.enc.Utf8);
      alert(decrypted);
    });
  });
  